# LaunchFlow funnel — full design and build handoff

Open `prototype.html` in a browser. The top preview picker opens all eight steps and five supporting screens. Use Save & continue to walk through the sample journey. The prototype is responsive and uses the real LaunchFlow logo and Geist font downloaded from the live site. It makes no network requests other than links you deliberately open; sample data stays in the current browser tab.

Give this whole folder to Claude Code and tell it:

> Read CLAUDE_START_HERE.md and implement this complete funnel inside the existing launchflow.co.uk repository. Use the included prototype and screenshots as the design reference. Follow the stack audit and engineering handoff, inspect the actual repository conventions, and complete the relevant acceptance checks.

Files:
- `CLAUDE_START_HERE.md` — paste-ready implementation task.
- `prototype.html` — all screens, clickable and responsive; run locally by opening the file.
- `DESIGN_AND_FLOW.md` — exact flow, components, content, tokens, responsive rules and additional state variants.
- `STACK_AUDIT.md` — public-site findings and limits, checked 10 September 2026.
- `ENGINEERING.md` — server persistence, APIs, DB entities, secure resume, upload and AI workflow, LaunchOS and Coolify integration.
- `brief.schema.json` — strict structured output contract for the generated brief.
- `QA_CHECKLIST.md` — meaningful production implementation tests.
- `PROTOTYPE_CHECKS.md` — results of the local visual prototype verification.
- `assets/launchflow-logo.png` — real current logo, unchanged.
- `assets/geist-latin.woff2` and `assets/Geist-OFL.txt` — matching site font and licence.
- `screens/` — desktop screens plus phone references.
- `storyboard.html` — every desktop screen in order for a quick visual review.

This is a design prototype and implementation pack. It has not changed or deployed launchflow.co.uk. PostgreSQL, Coolify and TypeScript are supported by the user's context and public site statements; public responses directly confirm Next.js and strongly indicate App Router. Exact versions, ORM and private configuration require repository inspection.
