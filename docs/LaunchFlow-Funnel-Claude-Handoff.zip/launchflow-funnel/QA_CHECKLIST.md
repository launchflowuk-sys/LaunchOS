# Acceptance checks for Claude Code

These are implementation gates, not claims that the production app has been tested here.

1. Enter a valid phone only, wait for committed Saved, close the tab before Continue. Staff can find the partial lead. Repeat email-only. Name/address-only stays an uncontactable draft.
2. Complete the contact step; fail all later writes. The first contact remains in PostgreSQL. No failed request displays Saved.
3. Rapid typing and navigation do not let an old response overwrite a new answer. Revision conflict across tabs is recoverable. Retrying the same mutation is idempotent.
4. Invalid email/phone leaves entered text visible and points to the field; draft persistence does not incorrectly mark the stage complete.
5. Back, review Edit, browser Back/Forward and refresh retain acknowledged choices. Changing a parent choice excludes stale conditional scope from submission while preserving it in the draft.
6. All stages reachable; required validation cannot be bypassed by typing a future-stage URL. Help-me-choose and budget guidance paths can complete.
7. Upload one allowed file, wrong-type file, disguised content and oversized file. Ready attachments are private; failed ones do not block finishing without them. Another session cannot access/delete them.
8. Two concurrent submit requests with the same key create one immutable submission and initial job. A timeout after commit returns the existing result on retry.
9. Stop the AI provider and mail service. Lead and submission remain successful. The deterministic brief is available; worker retries are bounded and visible to staff.
10. Kill a worker mid-job; an expired lease is recovered. Restart/redeploy the app; drafts, uploads and submissions survive.
11. Resume link GET by a scanner does not consume it. POST exchange works once; reuse/expiry/revocation reveal no data. Unknown-email response does not enumerate leads. Cookie scope works on the intended host.
12. Cross-session draft UUID guessing and cross-origin mutation requests fail. Raw answer strings render as text. Analytics and server logs contain no contact fields or resume tokens.
13. Generated JSON validates against schema. Unknown information stays unknown. Customer-uploaded prompt-injection text cannot trigger actions or override the generation task. Private contact details are excluded from AI input when not required.
14. Check 360, 390, 768, 1024 and 1440 widths, real iOS input focus, 200% zoom, keyboard, focus order, modal focus trap, screen-reader labels and reduced motion. No horizontal overflow or sticky action covering content.
15. Check marketing `/`, `/contact`, the new public funnel routes, API routes, image optimisation and portal login after middleware changes.
16. Confirm actual lint/type/build commands pass using the installed package manager. Run the focused DB/API/worker tests needed above against an isolated test database.

## Prototype verification delivered with this pack

The local visual prototype is separately checked for all 13 screen renders, responsive overflow, navigation, selection persistence and a complete sample submission. It has no production persistence, real email, AI, private upload service or CRM connection. Those are for Claude to implement and validate using the gates above.
