# Stack audit — 10 September 2026

This is a public-site inspection, not a repository audit. No access to production source, private deployment configuration or database was used.

| Finding | Evidence | Confidence / limit |
|---|---|---|
| Next.js powers the current public site | Live response `X-Powered-By: Next.js`; `/_next/static/` scripts and `/_next/image` images | Confirmed from public response |
| App Router is in use | `main-app` bundle, `app/(marketing)/site/layout`, `template`, `page` bundles; RSC router header values | Strong direct evidence; exact version unverified |
| Public homepage is rewritten to `/site` | `X-Middleware-Rewrite: /site` response header | Confirmed for `/`; full host/middleware logic unseen |
| React / TypeScript are relevant to the existing work | Site's web application services list names them alongside Next.js | React consistent with Next.js; TypeScript publicly stated, source not inspected |
| PostgreSQL | User statement and site's service description | Stated, not a direct inspection of this app's DB; ORM and version unknown |
| Coolify | User clarification interpreted as Coolify and the site says deployments use it | Publicly stated; project/build pack/private config unknown |
| Hetzner hosting | Site says it uses its own Hetzner servers | Publicly stated, not infrastructure verification |
| Client portal at os.launchflow.co.uk | Public navigation link to LaunchOS | Confirmed link; auth, API and schema unseen |
| Real logo asset | `/brand/launchflow-logo-transparent%40600.png` | Downloaded into this pack; use repository original when available |
| Tailwind CSS | Served stylesheet banner identifies Tailwind CSS v4.3.3 | Confirmed published CSS banner; inspect package/lockfile for installed version |
| Geist font | Served font CSS defines Geist and marketing font-family uses it | Confirmed; Latin font asset included with OFL licence |
| ORM, component library, mail provider, queue | Not established through public inspection | Inspect repository; do not assume Prisma, Drizzle, Redis or a vendor |

Public sources:
- [LaunchFlow homepage](https://launchflow.co.uk/) — current offering, stack statements, portal link, branding and HTML response.
- [Contact page](https://launchflow.co.uk/contact) — existing contact journey. Its copy says there is no mailing list or follow-up sequence. Preserve that distinction: requested return links and project replies are not a new abandoned-lead marketing campaign.
- [Original logo asset](https://launchflow.co.uk/brand/launchflow-logo-transparent%40600.png).
- [Next.js self-hosting documentation](https://nextjs.org/docs/app/guides/self-hosting) — background for preserving the existing self-hosted deployment, reverse proxy and multi-instance behaviour. Use documentation matching the installed version.
- [Coolify documentation](https://coolify.io/docs) — deployment reference; inspect the actual configured build pack and runtime instead of replacing them.

Observed public script paths included:
```
/_next/static/chunks/main-app-b4cca5ec5fc82da2.js
/_next/static/chunks/app/(marketing)/site/layout-d75a749a13c82ce2.js
/_next/static/chunks/app/(marketing)/site/template-1e49a59ea9f5f6fe.js
/_next/static/chunks/app/(marketing)/site/page-95caa5f09310edd5.js
```
These are evidence, not paths Claude should edit. Chunk hashes change with builds.

Recommended integration: expose `/start-project` on the public marketing host, use the app's existing PostgreSQL access layer, and integrate into the existing lead pipeline. Keep `/contact` available for a short message. Add a website-brief CTA on the homepage, relevant website service pages and pricing page without replacing unrelated navigation. The exact source paths and runtime settings must come from the repository.

Additional stylesheet inspection confirmed the marketing blue token is `#0969CA`; the funnel prototype uses the previously approved brighter `#0965EE` action colour. Claude may map the funnel action to the canonical marketing token if required, consistently across hover, focus and selected states. The shared font is Geist, weights 100–900, served at `/_next/static/media/22a5144ee8d83bca-s.p.woff2`.
