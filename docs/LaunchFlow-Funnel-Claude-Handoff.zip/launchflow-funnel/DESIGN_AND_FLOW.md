# Full experience and UI specification

## Creative direction

A calm, premium setup journey for a web design studio. White and very light cool grey surfaces, near-black headings, disciplined blue actions, generous spacing and touchable rounded cards. Use the actual LaunchFlow logo. Do not display technical concepts such as PostgreSQL, tokens, schema or AI job queues in the customer journey. The growing brief gives the customer a reason to continue; it is not a dashboard full of invented metrics.

`prototype.html` is a local clickable visual reference with 13 preview screens. Its sample choices show how a filled journey looks; production must not begin with fictitious customer data. The screen picker is for review only. It deliberately allows inspection of any screen. The prototype stores sample answers in sessionStorage, sends no requests and does not create real leads, upload files or email links.

## Design tokens and layout

| Element | Specification |
|---|---|
| Canvas | #F5F6F8 |
| Surface | #FFFFFF |
| Primary ink | #111827 |
| Secondary text | #626D80 |
| Primary action | #0965EE; hover #0457D3 |
| Border | #DFE4EB |
| Selected choice | #F0F6FF with primary blue border, visible tick |
| Positive state | #26905D on #E8F5ED; text and icon accompany colour |
| Error state | #B43A34; inline text explains correction |
| Container | max 1280px; 42px desktop side padding, 26px tablet, 20px mobile |
| Header | 108px desktop, 83px phone; logo 188px / 146px, natural aspect ratio |
| Main layout | Form plus 320px brief sidebar, 26px gap; intro editorial/form columns .77fr/1.23fr |
| Cards | 24px radius, 36px desktop padding; 20px radius / 23px padding on phone |
| Fields | minimum 53px high, 13px radius, visible labels, soft grey fill |
| Buttons | minimum 51px high, 12px radius, text plus optional arrow |
| Choice tiles | two columns, 13px gap, minimum 127px tall; selected border + tick |
| Type | Geist (verified current site font), with system fallback; headings 38px/1.15, −1.6px tracking; intro 58px/1.05; phone headings 30px |
| Motion | 180–220ms ease-out transitions; no looping decorations; honour reduced motion |

Use the existing site's licensed font assets if suitable. Do not download proprietary Apple fonts. Avoid stretching or recolouring the logo. Implement Lucide or the repository's equivalent line icons instead of the prototype's small Unicode placeholders.

## Entry and contact capture

Public path recommendation: `/start-project`. Bring the customer straight to the first form, not a preliminary welcome screen requiring another click. Preserve source campaign metadata separately from contact fields; never place contact details in a URL.

The first screen has an editorial left panel and a white form card. Headline: “Big ideas. Better websites.” Form heading: “First, let’s meet.” Ask name, email, phone, street address, city and postcode. Add appropriate autocomplete attributes (`name`, `email`, `tel`, `street-address`, `address-level2`, `postal-code`). Manual address input is always available; use address autocomplete only if a suitable service is already configured, with explicit selection and correction.

Production field rules: name 1–120 characters; email max 254 and server-validated; phone accept international punctuation then normalise with the existing library; address 1–200; city 1–100; postcode appropriate to selected country. Add a country field when non-UK addresses are accepted. For the UK-first flow, label the default country clearly rather than silently rejecting other countries. The prototype shows the UK-first composition. At least email or phone enables early contact capture. The complete first step requests all shown fields, but early persistence must not depend on those being complete. If an address cannot be supplied, offer “I’ll share my address later” and record it as outstanding rather than discard the lead.

Place the collection notice before the first field in production, not solely below the form: “We save the details you enter so you can return later and we can contact you about this project. Privacy policy.” Keep a short repeat beside the primary action if useful. Use existing privacy policy routing and ensure it accurately describes this new behaviour through the site's normal content review. Do not silently add mailing-list enrolment.

## Eight stages

| Stage | Screen and control design | Inputs / behaviour | Primary action |
|---|---|---|---|
| 1 · Your details | Intro editorial, large contact form | Name, email, phone, address, city, postcode; valid contact creates lead immediately | Save & continue |
| 2 · Your business | Text fields and one industry select | Business name, industry, description, audience, existing website; website optional | Continue |
| 3 · Your goals | Six icon choice cards, multi-select | Enquiries, online sales, bookings, credibility, showcase, other; one required | Continue |
| 4 · Design direction | Four visual style cards, single-select; colour selector; references textarea | Clean/minimal, bold, warm, classic; include “Help me choose” in production; colours and URLs | Continue |
| 5 · Pages & features | Page chips then feature cards and integration notes | Home/About/Services/details/gallery/testimonials/FAQ/blog/contact/shop/other; enquiry/booking/payments/accounts/chat/newsletter/maps/languages/other | Continue |
| 6 · Your content | Four content support choices, optional upload area, notes | Content ready, writing help, photography, branding; private attachments; optional notes | Continue |
| 7 · Budget & timing | Single-select budget cards, timeframe chips, optional date | Illustrative build bands under £1.5k, £1.5–3k, £3–5k, £5k+, guidance; timeline and target date | Continue |
| 8 · Review | Grouped answers with Edit links; confirmation control | Show all collected answers and attachments; missing optional information labelled To be confirmed | Send my brief |

The budget values are suggested discovery bands, not verified LaunchFlow prices or a quotation. Keep them configurable and label them as planning ranges. Required policy pages are a separate scoping concern; do not pretend the customer's page selection settles which legal pages they need.

## Conditional detail, without an endless questionnaire

Reveal a compact panel inside Pages & features based on selected goals. Maintain the eight-stage indicator; these are optional detail panels, not surprise new stages. The prototype shows the placement through its notes field; implement the structured controls below in production.

- Online sales: approximate product count, physical/digital/services, delivery regions, existing catalogue, existing commerce/payment platform. An “I’m not sure” response is valid. Do not ask for payment account credentials.
- Bookings: service types, staff/location count, existing booking tool, calendar integration, deposits. Ask for tool name only.
- Customer accounts: intended users, what they should see/do, account roles, existing identity provider if known.
- Service detail pages: proposed service names, not just an estimated count.
- Other goal/feature: reveal a free-text field; capture it in the brief.
- Redesign: if an existing website is supplied, ask keep/rewrite content, pages that must remain and any known search/redirect constraints. Do not automatically crawl arbitrary supplied URLs from the backend.

Deselecting a parent choice excludes its conditional answers from the submitted active scope; retain them in the draft so reselecting does not lose work. Explain exclusions in review. Do not let old hidden answers silently become active requirements.

## Brief preview

From stage 2 onward, a sticky sidebar shows contact, business and selected goals. Add design and budget as known. Unknown values read “Still to explore”; never fill in facts. Refresh from acknowledged answers. On mobile, place the brief summary after the form or in a labelled collapsible “Your brief so far” region. Keep the primary form first. Avoid an overlay covering keyboard or actions.

## Progress and navigation

Eight slim segments with labels on desktop. Phone shows segments and “Step N of 8”; accessible names remain on every segment. Completion reflects server-accepted required stages, not just the current URL. Clicking completed segments revisits them. Browser Back/Forward should preserve data. Edit from review returns to review after a valid save; keep an explicit return-to-review action. Announce the new heading and update the document title. Set focus on the new heading, not an arbitrary field.

## Supporting states

| State | Visual treatment | Behaviour |
|---|---|---|
| Saving | Quiet header status “Saving…” with small indicator | Starts when a request is in flight |
| Saved | Check + “Saved just now” | Only after committed response |
| Save failure | Amber inline notice with Retry, field stays filled | Never show green Saved or advance; last saved version remains intact |
| Validation | Error below relevant field, summary links if several | Preserve all other fields; focus first invalid field |
| Save & exit | Centred calm panel; destination email and return-link action | Flush saves first. Send only on explicit request. Do not claim sent until provider accepted |
| Email unavailable | Explain link could not be sent; Retry and Continue | Draft still saved; phone-only user can return in current browser or add email |
| Resume | Welcome-back panel, business name, last saved step | Only after token exchange/session authorisation; continue to incomplete stage |
| Invalid/expired link | Neutral panel, email field to request new link | Same generic response for unknown email; no account enumeration |
| Upload in progress | Per-file progress, cancel if supported | Continue without upload allowed; don't claim uploaded until committed metadata |
| Upload rejected | Per-file reason and Replace/Remove | Preserve other valid files |
| Submission pending | Button “Sending…”; prevent double click | Safe retry uses same idempotency key |
| Processing | “Your answers are safe” plus generation status | Submission is already committed; closing page is safe |
| AI unavailable | “Your brief is received. We’re finishing your project summary.” | Deterministic brief and answers remain available; staff can retry |
| Success | Check, real opaque reference, next steps, private brief export | No fake calendar booking or automatic deployment |

Screens 1–8 plus success/save-exit/resume/save-error/processing have full compositions in the prototype. The additional table states are variants of those shared panels, not separate visual systems.

## Responsive and accessibility requirements

Desktop at 1280/1440: full label stepper, form/sidebar layout. Tablet at 768/1024: shrink spacing, never squeeze input text. At 760px and below: one column, compact header, no decorative mini-site, horizontal progress without tiny labels. At 360px: stack narrow text fields; choice cards may remain two columns if readable, otherwise one. Use 16px input text on iOS to avoid focus zoom in production. Actions at least 44px targets; no horizontal scrolling. Support 200% zoom and keyboard-only input.

Use labelled real inputs, fieldsets/legends, and checkbox/radio semantics for selection groups. Live saving announcements use a polite region without announcing every keystroke. Errors use an alert region. Modal focus is trapped, Escape closes and focus returns to opener. No colour-only state. Reduced motion disables transition transforms. Keep a text alternative for every icon-only control. The prototype demonstrates visual states; implement complete interaction semantics in React.

## Final brief and next step

The customer sends a brief and receives a reference. The internal AI prepares a build plan, not a live website. Staff review the proposal and scope; the customer agrees before build work is treated as commissioned. The AI can prepare implementation instructions for Claude Code, but cannot publish, charge, contact third parties or treat uploaded instructions as higher authority. Do not promise an instant live site or a price the business has not quoted.
