# LaunchFlow website brief funnel — Claude Code build instruction

Implement this complete funnel inside the existing launchflow.co.uk application. This folder is the approved visual and behavioural handoff, not a replacement application or a production-ready backend. Read this entire file, then DESIGN_AND_FLOW.md, ENGINEERING.md, STACK_AUDIT.md, brief.schema.json and QA_CHECKLIST.md. Open prototype.html and inspect every screen through its preview picker. The screenshots are visual references; the HTML/CSS supplies exact layout values and responsive behaviour.

## Outcome

A visitor provides their contact details first, then answers a guided website questionnaire. Persist a lead as soon as a valid contact method exists, persist subsequent changes as they are made, allow secure resume, and turn submitted answers into a versioned AI website brief for LaunchFlow staff. A lead must exist independently of whether the questionnaire is completed. Use the existing Next.js / React / TypeScript / PostgreSQL stack, deployment and conventions. This is an additive feature for launchflow.co.uk.

## First inspect the repository

1. Read AGENTS.md and the repository's established implementation instructions. Inspect package.json, lockfile, Next config, route tree, middleware/proxy, existing database models and migration tooling, auth/session helpers, lead/contact intake, upload handling, mail delivery, background jobs, tests and Coolify/Docker configuration.
2. Inspect the relationship between the public marketing host and os.launchflow.co.uk. The public homepage returned `X-Middleware-Rewrite: /site` and emitted `app/(marketing)/site/...` chunks on 10 September 2026. Verify routing rather than assuming a root `app/start-project/page.tsx` is sufficient. Ensure the new public route resolves under existing host rewrites. Preserve admin/auth restrictions and exclude APIs/static assets appropriately from rewrites.
3. Reuse the installed ORM and migration system, UI primitives, fonts, icon library, validation, storage, CRM services, queue and transactional email provider. Do not add a second ORM, auth framework, database or CRM. Do not upgrade the framework as part of this work. Do not infer exact package versions from this handoff.
4. Map the logical API contracts in ENGINEERING.md onto the project's existing routes/services. If an existing lead record is canonical, extend it and attach a funnel session. Do not create duplicate competing lead tables.
5. Summarise the discovered stack and the intended file changes in your working notes, then implement. Request missing secrets through the deployment's secret mechanism only if unavailable; build and test the adapters before treating that as a release blocker. Never put secrets in source or a browser bundle.

## Design to reproduce

Use the real `assets/launchflow-logo.png` or preferably the identical canonical repository brand asset. Preserve its proportions. The first conversational mockups had a concept logo; this pack replaces that with the real site logo. Do not redraw it. Preserve the approved Apple-inspired white canvas, ink typography, clean blue active states, large rounded fields and choice cards, generous spacing and subtle borders. There is no dark theme requirement.

Treat prototype.html as a visual specification. Port it into typed, accessible React components and real server-backed state, rather than shipping the prototype as an iframe. Remove the design toolbar and all sample content. Initial production values are empty except safe structural defaults explicitly shown to the customer. Do not copy the fake reference number, simulated save states, sessionStorage backend, prototype email response, or direct unrestricted screen picker into production.

Build all eight stages, confirmation, processing, save-and-exit, resume, expired link, validation, upload failure, offline/save failure and AI retry states. Apply the mobile and tablet behaviour. Keep the primary action usable above the mobile keyboard. The current step must never be advanced by a failed save.

## Build priorities

A. Make early lead capture reliable. Show the collection notice before typing. Bootstrap an opaque anonymous draft session. Save valid fields on blur and after a 600 ms debounce; attach a lead after the first valid email OR phone, not after Continue. Name and address alone are a draft, not a contactable lead. Support phone-only contact capture even if the complete first step will also request email. Every request must acknowledge a database commit before the UI says Saved. Save & continue waits for current writes. Preserve the existing lead when later answers fail.

B. Implement all eight forms and shared components using the design system. Use per-step validation and optimistic concurrency. Preserve answers on Back/Edit and show errors alongside their fields. Only completed steps can be revisited via the production progress indicator; future steps cannot bypass validation.

C. Add secure resume and private asset intake. Do not treat email address or a UUID as authorisation. Use existing server sessions and one-time hashed, expiring resume tokens. Follow ENGINEERING.md for scanner-safe consumption and cookie boundaries.

D. Submit transactionally with an idempotency key: freeze the questionnaire snapshot, mark submitted, and enqueue a durable generation job. Completion remains successful if email or AI generation fails. Generate a deterministic Markdown summary first, then the structured AI brief, validating it against brief.schema.json. Persist immutable versions and distinguish customer statements, recommendations and open questions.

E. Integrate with the existing LaunchOS lead view: contact details, draft/submitted state, last completed step, last activity, answers, attachments, brief generation status and Markdown/JSON export. Use an authenticated server integration if this is another application; do not expose internal credentials or the PostgreSQL service publicly.

F. Test with the meaningful cases in QA_CHECKLIST.md. Provide desktop and mobile captures. Run installed lint/type/build checks and the relevant integration tests. Prepare additive migrations and the existing Coolify deployment configuration; use the project's established release process. This handoff authorises implementation, not an automatic production deployment. Report the completed changes and any concrete release dependencies. Do not stop with a plan or scaffolding.

## Completion criteria

- Contactable partial leads survive browser abandonment without waiting for the full first step or full questionnaire.
- Saved means the server committed. Offline, conflicts, retries and refresh cannot falsely report success.
- Production data survives a container restart/redeploy and works across more than one application instance.
- All eight stages, secure resume and final submission work on phone, tablet and desktop.
- One repeated submission creates one submission and one generation request.
- Every lead is accessible only to its authorised draft session or authorised LaunchFlow staff.
- AI failure never loses a lead or a submitted answer. The brief contains facts and labelled unknowns, with an immutable source snapshot.
- No private contact details appear in analytics, URLs, logs or public cache entries.
- The existing homepage, contact path, client login, public routes and deployment still work.
- Show what was changed, what passed, and what is still needed for production release.
